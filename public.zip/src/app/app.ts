import { Location } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { filter, map } from 'rxjs';

import { AnalyticsService } from './core/analytics.service';
import { ContinuityService } from './core/continuity.service';


const LANDING_ROUTES = ['/wpp-bebelzinha', '/cortadores', '/jantar-resolvido'];

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, RouterLinkActive, RouterOutlet],
  selector: 'app-root',
  styleUrl: './app.scss',
  templateUrl: './app.html',
})
export class App {
  private readonly router = inject(Router);
  private readonly location = inject(Location);

  private readonly url = toSignal(
    this.router.events.pipe(
      filter((event): event is NavigationEnd => event instanceof NavigationEnd),
      map((event) => event.urlAfterRedirects),
    ),
    { initialValue: this.router.url === '/' ? this.location.path() || '/' : this.router.url },
  );


  readonly isRecipePage = computed(() => /^\/comidinhas\/[^/]+\/?$/.test(this.url().split(/[?#]/)[0]));

  readonly isLanding = computed(() => {
    const url = this.url();
    const tree = this.router.parseUrl(url);
    const path = tree.root.children['primary']?.segments.map(segment => segment.path).join('/') ?? '';
    // Ambas as versões do experimento precisam aparecer como landing pages,
    // mesmo nos links de prévia sem parâmetros de campanha.
    const salesPage = path === 'produtos' || path === 'produtos/refeicao-resolvida'
      || path === 'produtos/refeicao-resolvida/teste-a'
      || path === 'produtos/refeicao-resolvida/teste-b'
      || path === 'produtos/refeicao-resolvida/sem-delivery';
    return salesPage || LANDING_ROUTES.some(route => url.startsWith(route));
  });

  constructor() {
    inject(AnalyticsService);
    inject(ContinuityService);
  }
}
